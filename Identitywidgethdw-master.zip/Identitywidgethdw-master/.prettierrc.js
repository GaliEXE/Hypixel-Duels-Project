module.exports = {
  semi: true,
  singleQuote: false,
  trailingComma: "none",
  tabWidth: 2
};
